/**
 * خادم اللعب الجماعي والماتش ميكينج التلقائي للعبة شطرنج الملوك 3D
 * يمكن رفعه مجاناً على Render.com أو Railway.app
 */
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

const rooms = new Map();
let waitingPlayer = null;

app.get('/', (req, res) => {
  res.send({ status: 'Royal 3D Chess Online Server is Running', activeRooms: rooms.size });
});

io.on('connection', (socket) => {
  // 1. البحث التلقائي عن خصم عشوائي (Auto-Matchmaking)
  socket.on('find_random_match', ({ playerName }) => {
    if (waitingPlayer && waitingPlayer.id !== socket.id) {
      const roomCode = 'MCH' + Math.floor(100 + Math.random() * 900);
      socket.join(roomCode);
      waitingPlayer.socket.join(roomCode);

      waitingPlayer.socket.emit('match_found', {
        roomCode,
        myColor: 'w',
        opponentName: playerName
      });
      socket.emit('match_found', {
        roomCode,
        myColor: 'b',
        opponentName: waitingPlayer.playerName
      });
      waitingPlayer = null;
    } else {
      waitingPlayer = { id: socket.id, playerName, socket };
    }
  });

  // 2. إرسال واستقبال النقلات والدردشة داخل الغرفة
  socket.on('room_packet', ({ roomCode, packet }) => {
    socket.to(roomCode).emit('room_packet', packet);
  });

  socket.on('disconnect', () => {
    if (waitingPlayer && waitingPlayer.id === socket.id) {
      waitingPlayer = null;
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Royal 3D Chess Server listening on port ${PORT}`);
});
